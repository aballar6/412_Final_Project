Author: Eric Grimm
Last Date Modified: 11/20/2020
These php files are for postgressql queries. The format to call them are as follows:

php fileName.php input1 input2...

The output is currently in html format:

<table>
<tr>
"result 1"
</tr>
<tr>
"result 2"
</tr>
.
.
.
</table>
