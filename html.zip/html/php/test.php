<?php 
    echo $_POST['gID'];
    ?>